package com.cg.jpademo.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.jpademo.entity.Mobile;

public class TestMobile {

public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("MyPersistenceUnit");
		
		EntityManager em=emf.createEntityManager();
		
		Mobile m1=new Mobile();
		m1.setMobile_company("Samsung");
		em.getTransaction().begin();
		em.persist(m1);
		System.out.println("Mobile Object Added.....");
		em.getTransaction().commit();
		
		em.close();
		emf.close();

	}

}
